import React from 'react'

const Discover = () => {
  return (
    <div>discover</div>
  )
}

export default Discover