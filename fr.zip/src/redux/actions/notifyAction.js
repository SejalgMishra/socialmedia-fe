export const TYPES = {
    NOTIFY : 'NOTIFY'
}
