import React from 'react'

const FollowBtn = () => {
  return (
    <button className="p-2 bg-blue-700 rounded-lg text-white">FollowBtn</button>
  )
}

export default FollowBtn