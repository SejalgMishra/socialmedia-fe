import React from 'react'

const Commnets = () => {
  return (
    <div>Commnets</div>
  )
}

export default Commnets