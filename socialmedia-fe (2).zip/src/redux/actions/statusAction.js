export const TYPES = {
    STATUS : "STATUS"
}